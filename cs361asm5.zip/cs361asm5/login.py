from ui_helpers import display_error

VALID_USERNAME = "user"
VALID_PASSWORD = "pass123"

def validate_credentials(username, password):
    """Checks if the provided credentials match the valid ones."""
    return username == VALID_USERNAME and password == VALID_PASSWORD

def login_user(username, password):
    """Attempts to log in the user and returns True if successful, False otherwise."""
    if validate_credentials(username, password):
        print("Login successful!")
        return True  # Login was successful
    else:
        display_error("Invalid credentials. Please try again.", delay=0.5)
        return False  # Login failed

