from dashboard import update_dashboard_with_income
from ui_helpers import display_error
import re  # To help validate the date format

def validate_income(amount, source, date):
    # Check if the amount is greater than zero
    if amount <= 0:
        display_error("Amount must be greater than zero.")
        return False

    # Check if the source is not empty
    if not source.strip():
        display_error("Income source cannot be empty.")
        return False

    # Check if the date format is correct (MM-DD-YYYY)
    if not re.match(r"^(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])-\d{4}$", date):
        display_error("Date must be in MM-DD-YYYY format.")
        return False

    return True

income_entries = []

def save_income_entry(amount, source, date):
    income_entries.append({
        "amount": amount,
        "source": source,
        "date": date
    })

def add_income(amount, source, date):
    # Validate input details
    if not validate_income(amount, source, date):
        return  # Exit the function if validation fails

    # Save the income entry and update the dashboard if validation passes
    save_income_entry(amount, source, date)
    update_dashboard_with_income()
