from login import login_user
from income import add_income
from expense import add_expense
from dashboard import load_dashboard

def main():
    print("Welcome to the Personal Finance App")

    # Prompt user for login
    username = input("Enter username: ")
    password = input("Enter password: ")
    
    # Attempt login
    if login_user(username, password):
        load_dashboard()  # Load dashboard after successful login
    else:
        return  # Exit if login failed

    # Main menu after login
    while True:
        print("\nPersonal Finance App")
        print("1. Add Income")
        print("2. Add Expense")
        print("3. Exit")

        choice = input("Select an option: ")

        if choice == "1":
            # Add Income
            try:
                amount = float(input("Enter income amount: "))
                source = input("Enter income source: ")
                date = input("Enter income date (MM-DD-YYYY): ")
                add_income(amount, source, date)
                print("Income added successfully.")
            except ValueError:
                print("Please enter a valid number for the amount.")

        elif choice == "2":
            # Add Expense
            try:
                amount = float(input("Enter expense amount: "))
                category = input("Enter expense category: ")
                date = input("Enter expense date (MM-DD-YYYY): ")
                add_expense(amount, category, date)
                print("Expense added successfully.")
            except ValueError:
                print("Please enter a valid number for the amount.")

        elif choice == "3":
            print("Exiting...")
            break

        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
