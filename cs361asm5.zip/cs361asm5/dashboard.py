def load_dashboard():
    print("Dashboard loaded successfully.")

def update_dashboard_with_income():
    print("Dashboard updated with new income entry.")

def update_dashboard_with_expense():
    print("Dashboard updated with new expense entry.")
