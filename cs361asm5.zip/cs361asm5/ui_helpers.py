import time

def display_error(message, delay=0.5):
    time.sleep(delay)
    print(f"Error: {message}")
