from dashboard import update_dashboard_with_expense
from ui_helpers import display_error
import re  # To help validate the date format

def validate_expense(amount, category, date):
    # Check if the amount is greater than zero
    if amount <= 0:
        display_error("Amount must be greater than zero.")
        return False

    # Check if the category is not empty
    if not category.strip():
        display_error("Expense category cannot be empty.")
        return False

    # Check if the date format is correct (MM-DD-YYYY)
    if not re.match(r"^(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])-\d{4}$", date):
        display_error("Date must be in MM-DD-YYYY format.")
        return False

    return True

expense_entries = []

def save_expense_entry(amount, category, date):
    expense_entries.append({
        "amount": amount,
        "category": category,
        "date": date
    })

def add_expense(amount, category, date):
    # Validate input details
    if not validate_expense(amount, category, date):
        return  # Exit the function if validation fails

    # Save the expense entry and update the dashboard if validation passes
    save_expense_entry(amount, category, date)
    update_dashboard_with_expense()
